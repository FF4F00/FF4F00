{
  description = "A very basic flake";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs?ref=nixos-unstable";
  };

  outputs = { nixpkgs, ... } @ inputs: (
    let
      pkgs = nixpkgs.legacyPackages.aarch64-darwin;
    in
    {
      packages.aarch64-darwin.hello = pkgs.hello;
      packages.aarch64-darwin.default = pkgs.hello;

      # nix develop .#cfg       # Config management (if needed)
      devShells.aarch64-darwin.cfg = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };
      
      # nix develop .#src       # Build environment for source installers
      devShells.aarch64-darwin.src = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };


      # nix develop .#bauhaus   # UI/UX development
      devShells.aarch64-darwin.bauhaus = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };
      
      # nix develop .#desktop   # General dev environment
      devShells.aarch64-darwin.desktop = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };
      
      # nix develop .#foundry   # CD environment
      devShells.aarch64-darwin.foundry = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };
      
      # nix develop .#houston   # CI environment
      devShells.aarch64-darwin.houston = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };      
      
      # nix develop .#toolbox   # Field Notes
      devShells.aarch64-darwin.journal = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };
      
      # nix develop .#toolbox   # Secrets
      devShells.aarch64-darwin.secrets = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };
      
      # nix develop .#toolbox   # Utilities
      devShells.aarch64-darwin.toolbox = pkgs.mkShell{ buildInputs = [pkgs.hello ]; };

    }
  );
}




