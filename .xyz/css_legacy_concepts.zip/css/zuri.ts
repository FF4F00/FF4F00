const zuri = "zuri.css";

function css(zuri) {
  const head = document.getElementsByTagName("HEAD")[0];
  const link = document.createElement("link");

  function cdn(zuri) {

    link.rel  = "stylesheet";
    link.type = "text/css";
    link.href = zuri;
  }

  head.appendChild(link);
  const x = cdn(zuri);
  return x;

}

css(zuri);



class Expo extends HTMLElement {

}

